package com.xumo;

import java.util.Date;

public class Campaign {
    private Integer cid;
    private String name;
    private Date startDate;
    private Date endDate;


    public Integer getCid() {
        return cid;
    }

    public Campaign setCid(Integer cid) {
        this.cid = cid;
        return this;
    }

    public String getName() {
        return name;
    }

    public Campaign setName(String name) {
        this.name = name;
        return this;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Campaign setStartDate(Date startDate) {
        this.startDate = startDate;
        return this;
    }

    public Date getEndDate() {
        return endDate;
    }

    public Campaign setEndDate(Date endDate) {
        this.endDate = endDate;
        return this;
    }
}
