package com.xumo;

import com.xumo.util.MyReader;

import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Application {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MMM-yyyy");

    public static void main(String args[]) {
        List<Campaign> activeCampaigns = loadActiveCampaigns(args[0]);
        Map<Integer, Banner> bannerMap = loadBanners(args[1]);
        int numAds = Integer.parseInt(args[2]);
        for (int i = 0; i < numAds; i++) {
            int index = ThreadLocalRandom.current().nextInt(0, activeCampaigns.size());
            Campaign campaign = activeCampaigns.get(index);
            Banner banner = bannerMap.get(campaign.getCid());
            System.out.println(banner.getUrl());
        }
    }

    private static List<Campaign> loadActiveCampaigns(String path) {
        Date activeDate = new Date();
        ArrayList<String[]> lines = MyReader.readFile(path);
        List<Campaign> activeCampaigns = new ArrayList<>();
        for (String[] line : lines) {
            Campaign campaign = toCampaign(line);
            if (isActive(activeDate, campaign)) {
                activeCampaigns.add(campaign);
            }
        }
        return activeCampaigns;
    }

    private static Map<Integer, Banner> loadBanners(String path) {
        Date activeDate = new Date();
        Map<Integer, Banner> bannerMap = new HashMap<>();
        ArrayList<String[]> lines = MyReader.readFile(path);
        for (String[] line : lines) {
            Banner banner = toBanner(line);
            bannerMap.put(banner.getCid(),banner);
        }
        return bannerMap;
    }

    private static Campaign toCampaign(String[] values) {
        try {
            return new Campaign().setCid(Integer.parseInt(values[0])).setName(values[1]).setStartDate(DATE_FORMAT.parse(values[2]))
                    .setEndDate(DATE_FORMAT.parse(values[3]));
        } catch (ParseException e) {
            throw new RuntimeException("Error parsing file invalid date " + e.getMessage());
        }
    }

    private static Banner toBanner(String[] values) {
        return new Banner().setBid(Integer.parseInt(values[0])).setCid(Integer.parseInt(values[1])).setUrl(values[2]);
    }

    private static boolean isActive(Date activeDate, Campaign campaign) {
        return campaign.getEndDate().after(activeDate) && campaign.getStartDate().before(activeDate);
    }
}
