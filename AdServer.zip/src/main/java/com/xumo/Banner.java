package com.xumo;

public class Banner {
    private Integer bid;
    private Integer cid;
    private String url;

    public Integer getBid() {
        return bid;
    }

    public Banner setBid(Integer bid) {
        this.bid = bid;
        return this;
    }

    public Integer getCid() {
        return cid;
    }

    public Banner setCid(Integer cid) {
        this.cid = cid;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public Banner setUrl(String url) {
        this.url = url;
        return this;
    }
}
